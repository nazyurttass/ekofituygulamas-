import java.sql.*;
import java.util.Scanner;
import java.util.Random;


public class Ekofit {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/ekofit";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "123naz123";

    private static Connection connection = null;
    private static Scanner scanner = new Scanner(System.in);
    private static int aktifUyeId = -1;
    private static String aktifUyeIsim = "";

    private static final String[] sporlar = {
            "Yürüyüş", "Koşu", "Bisiklet", "Yüzme",
            "Fonksiyonel Antrenman", "Kuvvet Antrenmanı", "HIIT"
    };

    public static void main(String[] args) {
        if (baglantiyiKur()) {
            anaMenu();
            baglantiyiKapat();
        } else {
            System.out.println("Uygulama sonlandırıldı.");
        }
    }


    private static boolean baglantiyiKur() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("Veritabanı bağlantısı başarılı!");
            return true;
        } catch (Exception e) {
            System.out.println("Veritabanı bağlantısı başarısız: " + e.getMessage());
            return false;
        }
    }


    private static void baglantiyiKapat() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Veritabanı bağlantısı kapatıldı.");
            }
        } catch (SQLException e) {
            System.out.println("Bağlantı kapatma hatası: " + e.getMessage());
        }
    }


    private static void anaMenu() {
        while (true) {
            System.out.println("\n===== EKOFİT SPOR SALONU =====");
            System.out.println("1- Giriş Yap");
            System.out.println("2- Üye Ol");
            System.out.println("0- Çıkış");
            System.out.print("Seçiminiz: ");
            String secim = scanner.nextLine();

            switch (secim) {
                case "1": girisYap(); break;
                case "2": uyeOl(); break;
                case "0": return;
                default: System.out.println("Geçersiz seçim! Lütfen tekrar deneyin.");
            }
        }
    }


    private static void girisYap() {
        System.out.print("Öğrenci Numarası: ");
        String ogrenciNo = scanner.nextLine();
        System.out.print("Şifre: ");
        String sifre = scanner.nextLine();

        String query = "SELECT uye_id, isim FROM uyeler WHERE ogrenci_no = ? AND sifre = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, ogrenciNo);
            stmt.setString(2, sifre);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                aktifUyeId = rs.getInt("uye_id");
                aktifUyeIsim = rs.getString("isim");
                System.out.println("Hoş geldiniz, " + aktifUyeIsim + "!");
                menu();
            } else {
                System.out.println("Hatalı öğrenci numarası veya şifre!");
            }

        } catch (SQLException e) {
            System.out.println("Giriş hatası: " + e.getMessage());
        }
    }


    private static void uyeOl() {
        System.out.print("İsim: ");
        String isim = scanner.nextLine();
        System.out.print("Öğrenci Numarası: ");
        String ogrenciNo = scanner.nextLine();
        System.out.print("Şifre: ");
        String sifre = scanner.nextLine();

        String checkQuery = "SELECT COUNT(*) FROM uyeler WHERE ogrenci_no = ?";
        String insertQuery = "INSERT INTO uyeler (isim, ogrenci_no, sifre) VALUES (?, ?, ?)";

        try (PreparedStatement checkStmt = connection.prepareStatement(checkQuery)) {
            checkStmt.setString(1, ogrenciNo);
            ResultSet rs = checkStmt.executeQuery();
            rs.next();

            if (rs.getInt(1) > 0) {
                System.out.println("Bu öğrenci numarası zaten kayıtlı.");
                return;
            }

            try (PreparedStatement insertStmt = connection.prepareStatement(insertQuery)) {
                insertStmt.setString(1, isim);
                insertStmt.setString(2, ogrenciNo);
                insertStmt.setString(3, sifre);
                insertStmt.executeUpdate();
                System.out.println("Üyelik oluşturuldu. Giriş yapabilirsiniz.");
            }

        } catch (SQLException e) {
            System.out.println("Üye olurken hata oluştu: " + e.getMessage());
        }
    }


    private static void menu() {
        while (true) {
            System.out.println("\n===== ANA MENÜ =====");
            System.out.println("1- Kalori Hesapla");
            System.out.println("2- Spor Önerisi");
            System.out.println("3- Haftalık Spor Planı");
            System.out.println("0- Çıkış");

            String secim = scanner.nextLine();
            switch (secim) {
                case "1": kaloriHesaplaVeKaydet(); break;
                case "2": sporOnerisiniGoster(); break;
                case "3": haftalikPlaniGoster(); break;
                case "0": aktifUyeId = -1; aktifUyeIsim = ""; return;
                default: System.out.println("Geçersiz seçim.");
            }
        }
    }


    private static void kaloriHesaplaVeKaydet() {
        System.out.print("Egzersiz süresi (dakika): ");
        try {
            int dakika = Integer.parseInt(scanner.nextLine());
            if (dakika < 0) {
                System.out.println("Negatif süre girilemez!");
                return;
            }

            int kalori = dakika * 5;
            String spor = sporOnerisiYap(kalori);
            System.out.println("Harcadığınız kalori: " + kalori + " | Önerilen spor: " + spor);

            String query = "INSERT INTO egzersiz_kayitlari (uye_id, egzersiz_tipi, sure_dakika, yakilan_kalori) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setInt(1, aktifUyeId);
                stmt.setString(2, spor);
                stmt.setInt(3, dakika);
                stmt.setInt(4, kalori);
                stmt.executeUpdate();
                System.out.println("Egzersiz kaydı eklendi.");
            }

        } catch (NumberFormatException e) {
            System.out.println("Geçersiz sayı girdiniz.");
        } catch (SQLException e) {
            System.out.println("Veritabanı hatası: " + e.getMessage());
        }
    }


    private static void sporOnerisiniGoster() {
        System.out.print("Kalori miktarını giriniz: ");
        try {
            int kalori = Integer.parseInt(scanner.nextLine());
            if (kalori < 0) {
                System.out.println("Negatif kalori girilemez!");
                return;
            }
            System.out.println("Önerilen spor: " + sporOnerisiYap(kalori));
        } catch (NumberFormatException e) {
            System.out.println("Geçersiz sayı girdiniz.");
        }
    }


    private static String sporOnerisiYap(int kalori) {
        if (kalori <= 100) return "Yürüyüş";
        else if (kalori <= 200) return "Koşu";
        else if (kalori <= 300) return "Bisiklet";
        else if (kalori <= 400) return "Yüzme";
        else if (kalori <= 500) return "Fonksiyonel Antrenman";
        else if (kalori <= 600) return "Kuvvet Antrenmanı";
        else return "HIIT";
    }


    private static String rastgeleSporSec() {
        return sporlar[new Random().nextInt(sporlar.length)];
    }


    private static void haftalikPlaniGoster() {
        String[] gunler = {"Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"};
        for (String gun : gunler) {
            System.out.println(gun + ": " + rastgeleSporSec());
        }
    }
}